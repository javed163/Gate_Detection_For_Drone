class Detect(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv2 : __torch__.torch.nn.modules.container.___torch_mangle_181.ModuleList
  cv3 : __torch__.torch.nn.modules.container.___torch_mangle_206.ModuleList
  dfl : __torch__.ultralytics.nn.modules.block.DFL
  def forward(self: __torch__.ultralytics.nn.modules.head.Detect,
    argument_1: Tensor,
    argument_2: Tensor,
    argument_3: Tensor) -> Tensor:
    dfl = self.dfl
    cv3 = self.cv3
    _2 = getattr(cv3, "2")
    cv30 = self.cv3
    _1 = getattr(cv30, "1")
    cv31 = self.cv3
    _0 = getattr(cv31, "0")
    cv2 = self.cv2
    _20 = getattr(cv2, "2")
    cv20 = self.cv2
    _10 = getattr(cv20, "1")
    cv32 = self.cv3
    _21 = getattr(cv32, "2")
    _11 = getattr(_21, "1")
    act = _11.act
    cv21 = self.cv2
    _00 = getattr(cv21, "0")
    bs = ops.prim.NumToTensor(torch.size(argument_1, 0))
    _3 = int(bs)
    _4 = int(bs)
    _5 = int(bs)
    _6 = int(bs)
    _7 = int(bs)
    _8 = int(bs)
    _9 = torch.view((_00).forward(act, argument_1, ), [_8, 64, -1])
    _12 = torch.view((_10).forward(act, argument_2, ), [_7, 64, -1])
    _13 = torch.view((_20).forward(act, argument_3, ), [_6, 64, -1])
    x = torch.cat([_9, _12, _13], -1)
    _14 = torch.view((_0).forward(act, argument_1, ), [_5, 1, -1])
    _15 = torch.view((_1).forward(act, argument_2, ), [_4, 1, -1])
    _16 = torch.view((_2).forward(argument_3, ), [_3, 1, -1])
    _17 = torch.cat([_14, _15, _16], -1)
    _18 = (dfl).forward(x, )
    anchor_points = torch.unsqueeze(CONSTANTS.c0, 0)
    lt, rb, = torch.chunk(_18, 2, 1)
    x1y1 = torch.sub(anchor_points, lt)
    x2y2 = torch.add(anchor_points, rb)
    c_xy = torch.div(torch.add(x1y1, x2y2), CONSTANTS.c1)
    wh = torch.sub(x2y2, x1y1)
    dbox = torch.mul(torch.cat([c_xy, wh], 1), CONSTANTS.c2)
    _19 = torch.cat([dbox, torch.sigmoid(_17)], 1)
    return _19
